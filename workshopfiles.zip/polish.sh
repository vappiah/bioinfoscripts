#!/bin/bash

currdir=$(pwd)
mkdir $currdir/polished_assembly

pilon=$currdir/apps/pilon.jar
read1=$currdir/trimmed/MU45_trimmed_R1.fastq.gz
read2=$currdir/trimmed/MU45_trimmed_R2.fastq.gz  


mkdir $currdir/polishing_process
cd $currdir/polishing_process

echo "POLISING DRAFT ASSEMBLY"

echo "ROUND 1"

cp $currdir/MU45_SPADES_OUT/scaffolds.fasta ./raw_assembly.fasta
bwa index raw_assembly.fasta
bwa mem raw_assembly.fasta $read1 $read2 | samtools view - -Sb |samtools sort - -o mapping1.sorted.bam
samtools index mapping1.sorted.bam
java -jar  $pilon --genome raw_assembly.fasta --fix all --changes --frags mapping1.sorted.bam --output pilon_stage1|tee stage1.pilon


echo "Round2"

bwa index pilon_stage1.fasta
bwa mem pilon_stage1.fasta $read1 $read2| samtools view - -Sb | samtools sort - -o mapping2.sorted.bam
samtools index mapping2.sorted.bam
java -jar $pilon --genome pilon_stage1.fasta --fix all --changes --frags mapping2.sorted.bam --output pilon_stage2 | tee stage2.pilon



cp pilon_stage2.fasta $currdir/polished_assembly/MU45.polished.fasta
cd ../
cat polishing_process/pilon_stage2.changes

echo "polishing has been completed"
echo "polished assembly can be found in $currdir/polished_assembly"
